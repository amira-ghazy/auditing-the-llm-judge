# Auditing the LLM Judge

**Treating an LLM evaluator as a measurement instrument: a reliability and bias audit.**

Using an LLM to grade other models ("LLM-as-judge") is now standard practice. The judge is
rarely audited the way any other rating instrument would be. This project runs that audit:
it asks whether an LLM judge is *self-consistent*, whether it *agrees with humans*, and
whether it is swayed by things that have nothing to do with quality — answer length,
presentation order, and group membership.

The methods are borrowed straight from psychometrics, the century-old science of measuring
things you can't observe directly. The finding is simple: standard measurement audits catch
exactly the failure modes the LLM-as-judge literature has documented.

---

## The five checks

| # | Question | Method |
|---|----------|--------|
| 1 | Is the judge self-consistent? | Test-retest reliability (quadratic-weighted kappa across two scoring passes) |
| 2 | Does it agree with humans? | Weighted kappa / correlation vs human consensus |
| 3 | Is it swayed by verbosity? | Partial correlation of score with answer length, controlling for true quality |
| 4 | Is it fair across groups? | DIF-style invariance check: mean (judge − true quality) by group |
| 5 | Is it swayed by order? | Pairwise position-bias rate, scoring each pair in both orders |

---

## Results

| Check | Judge | Human reference | Read |
|-------|-------|-----------------|------|
| Self-consistency (κw) | **0.85** | 0.90 | reliable, but noticeably below human raters |
| Agreement with humans (κw) | **0.84** | — | strong, not perfect |
| Verbosity bias (partial r) | **+0.28** | +0.13 | judge rewards length far more than humans do |
| Group invariance (gap) | **0.24** | ~0 | scores group A higher than B at equal quality |
| Position bias (first-shown wins) | **62.5%** | 50% | clear order effect; verdict flips 38% of the time on swap |

**What this says.** The judge looks fine on the usual headline number (it agrees with humans
~84% of the time). The audit shows that headline hides three problems a deployment would care
about: it rewards verbose answers, it scores one group systematically higher at equal quality,
and in head-to-head mode it favors whichever answer it sees first 62.5% of the time. None of
these are visible from an agreement score alone.

---

## How the judge is modeled

The judge here is **simulated** to reproduce behaviors the literature documents — verbosity
bias and position bias are both reported in Zheng et al. (2023), *Judging LLM-as-a-Judge with
MT-Bench and Chatbot Arena*. The simulation exists so the audit is fully reproducible with no
API key or spend. The point of the project is the audit, not the simulation.

To audit a **real** judge, replace `judge_score` and `judge_pick_first` in `simulate.py` with
calls to the model. Everything downstream in `audit.py` is unchanged. The code is structured
so swapping in a live model (or a logged set of real judgments) is a one-function change.

---

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python simulate.py   # build the single-answer + pairwise datasets
python audit.py      # run the five checks, write results/audit.txt
```

---

## Why it matters

An LLM judge is a measurement instrument, and a measurement instrument you haven't audited is
a liability. Agreement with humans is necessary but not sufficient: a judge can agree on
average and still be unreliable run-to-run, biased toward length, unfair across groups, and
swayed by order. Each of those is a standard psychometric question with a standard method, and
each is routinely skipped in practice. This repo is a worked example of not skipping them.

---

## Repository structure

```
auditing-the-llm-judge/
├── README.md
├── requirements.txt
├── config.py        # bias magnitudes, sample sizes, paths
├── simulate.py      # items + biased judge + human raters (live-judge hook here)
├── audit.py         # the five checks
├── data/            # generated datasets (git-ignored)
└── results/         # audit report (git-ignored)
```

## Limitations and next steps

- The judge is simulated. The natural next step is to run the identical audit on a live model
  (the code is set up for it) and on logged human-vs-judge data such as MT-Bench.
- Position bias here is measured on synthetic pairs; on real data you would also separate
  position bias from genuine quality differences with a paired design.
- A fuller invariance analysis would use formal differential-item-functioning models rather
  than a mean gap, and report confidence intervals.

## License

MIT.
